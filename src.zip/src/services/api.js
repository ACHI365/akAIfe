
const API_URL = 'http://localhost:5000';

export const sendMessage = async (message) => {
  try {
    const response = await fetch(`${API_URL}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    return await response.json();
  } catch (error) {
    console.error('Error sending message:', error);
    // Return a fallback response for demo purposes
    return { 
      reply: "I'm sorry, I'm having trouble connecting to the server. Please try again later or check if the local server is running on port 5000." 
    };
  }
};
