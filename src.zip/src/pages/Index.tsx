
import React from 'react';
import ChatInterface from '../components/ChatInterface';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-travel-sand p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-6">
          <h1 className="text-3xl md:text-4xl font-bold text-travel-navy mb-2">
            Wanderlust Guide
          </h1>
          <p className="text-gray-600 max-w-lg mx-auto">
            Your AI travel companion to help plan your next adventure. Ask me about destinations, activities, or travel tips!
          </p>
        </header>
        
        <ChatInterface />
        
        <footer className="text-center text-gray-500 text-sm mt-8">
          <p>© 2025 Wanderlust Guide • Your friendly travel assistant</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
