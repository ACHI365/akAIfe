
import React, { useState } from 'react';
import { Send } from 'lucide-react';

const ChatInput = ({ onSendMessage, isLoading }) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim() && !isLoading) {
      onSendMessage(message);
      setMessage('');
    }
  };

  return (
    <form 
      onSubmit={handleSubmit} 
      className="flex items-center bg-white p-3 rounded-xl border border-gray-200 shadow-sm"
    >
      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Ask about your trip..."
        className="flex-grow px-4 py-2 focus:outline-none"
        disabled={isLoading}
      />
      <button
        type="submit"
        className={`ml-2 p-2 rounded-full ${
          isLoading || !message.trim() 
            ? 'bg-gray-200 cursor-not-allowed' 
            : 'bg-travel-teal hover:bg-travel-navy transition-colors'
        }`}
        disabled={isLoading || !message.trim()}
      >
        <Send size={18} className="text-white" />
      </button>
    </form>
  );
};

export default ChatInput;
