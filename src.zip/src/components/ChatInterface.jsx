
import React, { useRef, useEffect } from 'react';
import ChatBubble from './ChatBubble';
import ChatInput from './ChatInput';
import useChat from '../hooks/useChat';
import { MessageCircle } from 'lucide-react';

const ChatInterface = () => {
  const { messages, isLoading, handleSendMessage } = useChat();
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <div className="flex flex-col h-[80vh] max-w-3xl mx-auto">
      {/* Header */}
      <div className="bg-travel-teal text-white p-4 rounded-t-xl flex items-center">
        <MessageCircle className="mr-2" size={24} />
        <h1 className="text-xl font-semibold">Wanderlust Guide</h1>
      </div>
      
      {/* Chat Messages */}
      <div className="flex-1 p-4 overflow-y-auto bg-travel-sand chat-container rounded-b-xl">
        {messages.map((msg) => (
          <ChatBubble 
            key={msg.id} 
            message={msg.text} 
            isUser={msg.isUser} 
          />
        ))}
        
        {/* Loading indicator */}
        {isLoading && (
          <div className="flex justify-start mb-4">
            <div className="w-8 h-8 rounded-full bg-travel-teal flex items-center justify-center mr-2">
              <span className="text-white text-xs font-bold">WG</span>
            </div>
            <div className="chat-bubble-bot">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-travel-teal rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-travel-teal rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-travel-teal rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      {/* Input Area */}
      <div className="mt-4">
        <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
      </div>
    </div>
  );
};

export default ChatInterface;
