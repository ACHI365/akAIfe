
import React from 'react';

const ChatBubble = ({ message, isUser }) => {
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-travel-teal flex items-center justify-center mr-2">
          <span className="text-white text-xs font-bold">WG</span>
        </div>
      )}
      <div className={isUser ? 'chat-bubble-user' : 'chat-bubble-bot'}>
        {message}
      </div>
      {isUser && (
        <div className="w-8 h-8 rounded-full bg-travel-navy flex items-center justify-center ml-2">
          <span className="text-white text-xs">You</span>
        </div>
      )}
    </div>
  );
};

export default ChatBubble;
