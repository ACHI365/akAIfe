
import { useState } from 'react';
import { sendMessage } from '../services/api';
import { toast } from 'sonner';

const useChat = () => {
  const [messages, setMessages] = useState([
    { id: 1, text: "Hi there! I'm your Wanderlust Guide. Where are you thinking of traveling to?", isUser: false }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const addMessage = (text, isUser) => {
    setMessages(prev => [...prev, {
      id: Date.now(),
      text,
      isUser
    }]);
  };

  const handleSendMessage = async (message) => {
    if (!message.trim()) return;
    
    // Add user message to chat
    addMessage(message, true);
    
    // Set loading state
    setIsLoading(true);
    
    try {
      // Send message to API
      const response = await sendMessage(message);
      
      // Add bot response to chat
      addMessage(response.reply || "I'm not sure how to respond to that.", false);
    } catch (error) {
      console.error('Error in chat:', error);
      toast.error('Failed to get a response. Is the server running?');
      
      // Add fallback response
      addMessage("Sorry, I'm having trouble connecting. Please check if the server is running on localhost:5000.", false);
    } finally {
      setIsLoading(false);
    }
  };

  return { messages, isLoading, handleSendMessage };
};

export default useChat;
